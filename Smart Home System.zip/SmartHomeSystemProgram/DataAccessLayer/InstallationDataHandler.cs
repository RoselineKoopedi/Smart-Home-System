﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
     public class InstallationDataHandler
    {
        SqlConnectionStringBuilder connection = new SqlConnectionStringBuilder();
        string Query = null;
        public InstallationDataHandler()
        {
            connection.DataSource = "TAYLORKOOPS";
            connection.InitialCatalog = "SmartHomeSystemDB";
            connection.IntegratedSecurity = true;
        }
        public DataSet ReadInstallation(string tableName)
        {
            DataSet InstallationData = new DataSet();
            using (SqlConnection connect = new SqlConnection(connection.ToString()))
            {
                Query = string.Format("SELECT * FROM {0}", tableName);
                connect.Open();
                SqlDataAdapter Adapter = new SqlDataAdapter(Query, connect);
                Adapter.FillSchema(InstallationData, SchemaType.Source, tableName);
                Adapter.Fill(InstallationData, tableName);
                connect.Close();
            }

            return InstallationData;
        }
        public void InsertInstallation(int InstallationID, int OperationID, int ResidenceID, DateTime InstallationDate)
        {
            using (SqlConnection connect = new SqlConnection(connection.ToString()))
            {
                try
                {
                    Query = "INSERT INTO Installation(InstallationID,OperationID,ResidenceID,InstallationDate) Value( '" + InstallationID + "','" + OperationID + "','" + ResidenceID + "','" + InstallationDate + "')";
                    SqlCommand command = new SqlCommand(Query, connect);
                    command.ExecuteNonQuery();
                }
                catch (Exception )
                {

                }
                finally
                {
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close();
                    }
                }
            }
        }
        public void UpdateInstallation(int InstallationID, int OperationID, int ResidenceID, DateTime InstallationDate)
        {
            using (SqlConnection connect = new SqlConnection(connection.ToString()))
            {
                try
                {
                    Query = "UPDATE Installation SET ResidenceID= '" + ResidenceID + "', InstallationDate ='" + InstallationDate + "' WHERE InstallationID = '"+ InstallationID+"'";
                    SqlCommand command = new SqlCommand(Query, connect);
                    command.ExecuteNonQuery();
                }
                catch (Exception)
                {

                }
                finally
                {
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close();
                    }
                }
            }
        }
        public void DeleteInstallation(int InstallationID)
        {
            using (SqlConnection connect = new SqlConnection(connection.ToString()))
            {
                try
                {
                    Query = "DELETE FROM Installation WHERE InstallationID ='" + InstallationID + "'";
                    SqlCommand command = new SqlCommand(Query, connect);
                    command.ExecuteNonQuery();
                }
                catch (Exception )
                {

                }
                finally
                {
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close();
                    }
                }
            }
        }
    }
}
