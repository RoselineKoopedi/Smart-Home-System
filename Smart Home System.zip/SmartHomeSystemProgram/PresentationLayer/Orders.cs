﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace PresentationLayer
{
    public partial class Orders : Form
    {
        static Order ProductOrders = new Order();
        DataTable Ordertable = new DataTable();
        DataTable FilterOrders = new DataTable();
        public Orders()
        {
            InitializeComponent();
        }

        private void Orders_Load(object sender, EventArgs e)
        {

            
            Ordertable.Clear();
            Ordertable = ProductOrders.GetOrders();
            dgvOrders.DataSource = null;
            dgvOrders.DataSource = Ordertable;
            txtProductID.DataBindings.Add(new Binding("Text", Ordertable, "ProductID"));
            txtQuantity.DataBindings.Add(new Binding("Text", Ordertable, "Quantity"));
            txtPrice.DataBindings.Add(new Binding("Text", Ordertable, "TotalPrice"));
            txtOrderID.DataBindings.Add(new Binding("Text", Ordertable,"OrderID"));
            cmbCategory.DataSource = Ordertable;
            cmbCategory.DisplayMember = "ProductCatagory";
            cmbClientID.DataSource = Ordertable;
            cmbClientID.DisplayMember = "ClientID";
            cmbProductName.DataSource = Ordertable;
            cmbProductName.DisplayMember = "ProductName";

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int orderID = int.Parse(txtOrderID.Text);
            ProductOrders.DeleteOrder(orderID);
            MessageBox.Show("Order has been deleted", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
      
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            int orderID = int.Parse(txtOrderID.Text);
            string clientID = cmbClientID.Text;
            string productID = txtProductID.Text;
            string categoty = cmbCategory.Text;
            string name = cmbProductName.Text;
            DateTime date = DateTime.Parse(dtpOrders.Text);
            int quantity = int.Parse(txtQuantity.Text);
            double totalPrice = Double.Parse(txtPrice.Text);
            ProductOrders.UpdateOrder(orderID, clientID, productID, categoty, name, date, quantity, totalPrice);
            MessageBox.Show("Order has been updated", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ProductManagementDepartment pmd = new ProductManagementDepartment();
            this.Hide();
            pmd.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnOrderID_Click(object sender, EventArgs e)
        {
            int orderID = int.Parse(txtSearchID.Text);
            FilterOrders = ProductOrders.FiltereOrder(orderID);
            dgvOrders.DataSource = null;
            dgvOrders.DataSource = FilterOrders;
        }

        private void btnviewAll_Click(object sender, EventArgs e)
        {
            Ordertable.Clear();
            Ordertable = ProductOrders.GetOrders();
            dgvOrders.DataSource = null;
            dgvOrders.DataSource = Ordertable;
        }
    }
}
