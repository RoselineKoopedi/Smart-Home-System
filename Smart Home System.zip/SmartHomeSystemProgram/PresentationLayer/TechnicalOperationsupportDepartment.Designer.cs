﻿namespace PresentationLayer
{
    partial class TechnicalOperationsupportDepartment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.manipulateClientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addClientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateClientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteClientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.assignOperationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manipulateEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cALLCENTERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nEWCALLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgvTechnicalSupport = new System.Windows.Forms.DataGridView();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.PreviousOperation = new System.Windows.Forms.Button();
            this.NextOperation = new System.Windows.Forms.Button();
            this.LastOperation = new System.Windows.Forms.Button();
            this.FirstOperation = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTechnicalSupport)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manipulateClientsToolStripMenuItem,
            this.manipulateEmployeesToolStripMenuItem,
            this.cALLCENTERToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 18;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // manipulateClientsToolStripMenuItem
            // 
            this.manipulateClientsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addClientsToolStripMenuItem,
            this.updateClientsToolStripMenuItem,
            this.deleteClientsToolStripMenuItem,
            this.assignOperationsToolStripMenuItem});
            this.manipulateClientsToolStripMenuItem.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manipulateClientsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.manipulateClientsToolStripMenuItem.Name = "manipulateClientsToolStripMenuItem";
            this.manipulateClientsToolStripMenuItem.Size = new System.Drawing.Size(224, 20);
            this.manipulateClientsToolStripMenuItem.Text = "Manipulate Operations";
            // 
            // addClientsToolStripMenuItem
            // 
            this.addClientsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.addClientsToolStripMenuItem.Name = "addClientsToolStripMenuItem";
            this.addClientsToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.addClientsToolStripMenuItem.Text = "Add Operation";
            this.addClientsToolStripMenuItem.Click += new System.EventHandler(this.addClientsToolStripMenuItem_Click);
            // 
            // updateClientsToolStripMenuItem
            // 
            this.updateClientsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.updateClientsToolStripMenuItem.Name = "updateClientsToolStripMenuItem";
            this.updateClientsToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.updateClientsToolStripMenuItem.Text = "Update Operation";
            this.updateClientsToolStripMenuItem.Click += new System.EventHandler(this.updateClientsToolStripMenuItem_Click);
            // 
            // deleteClientsToolStripMenuItem
            // 
            this.deleteClientsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.deleteClientsToolStripMenuItem.Name = "deleteClientsToolStripMenuItem";
            this.deleteClientsToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.deleteClientsToolStripMenuItem.Text = "Delete Operation";
            this.deleteClientsToolStripMenuItem.Click += new System.EventHandler(this.deleteClientsToolStripMenuItem_Click);
            // 
            // assignOperationsToolStripMenuItem
            // 
            this.assignOperationsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.assignOperationsToolStripMenuItem.Name = "assignOperationsToolStripMenuItem";
            this.assignOperationsToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.assignOperationsToolStripMenuItem.Text = "Assign Operations";
            this.assignOperationsToolStripMenuItem.Click += new System.EventHandler(this.assignOperationsToolStripMenuItem_Click);
            // 
            // manipulateEmployeesToolStripMenuItem
            // 
            this.manipulateEmployeesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewEmployeesToolStripMenuItem,
            this.addEmployeesToolStripMenuItem,
            this.deleteEmployeesToolStripMenuItem,
            this.updateEmployeesToolStripMenuItem});
            this.manipulateEmployeesToolStripMenuItem.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manipulateEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.manipulateEmployeesToolStripMenuItem.Name = "manipulateEmployeesToolStripMenuItem";
            this.manipulateEmployeesToolStripMenuItem.Size = new System.Drawing.Size(217, 20);
            this.manipulateEmployeesToolStripMenuItem.Text = "Manipulate Employees";
            // 
            // viewEmployeesToolStripMenuItem
            // 
            this.viewEmployeesToolStripMenuItem.BackColor = System.Drawing.SystemColors.HighlightText;
            this.viewEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.viewEmployeesToolStripMenuItem.Name = "viewEmployeesToolStripMenuItem";
            this.viewEmployeesToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.viewEmployeesToolStripMenuItem.Text = "View Employees";
            this.viewEmployeesToolStripMenuItem.Click += new System.EventHandler(this.viewEmployeesToolStripMenuItem_Click);
            // 
            // addEmployeesToolStripMenuItem
            // 
            this.addEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.addEmployeesToolStripMenuItem.Name = "addEmployeesToolStripMenuItem";
            this.addEmployeesToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.addEmployeesToolStripMenuItem.Text = "Add Employees";
            this.addEmployeesToolStripMenuItem.Click += new System.EventHandler(this.addEmployeesToolStripMenuItem_Click);
            // 
            // deleteEmployeesToolStripMenuItem
            // 
            this.deleteEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.deleteEmployeesToolStripMenuItem.Name = "deleteEmployeesToolStripMenuItem";
            this.deleteEmployeesToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.deleteEmployeesToolStripMenuItem.Text = "Delete Employees";
            this.deleteEmployeesToolStripMenuItem.Click += new System.EventHandler(this.deleteEmployeesToolStripMenuItem_Click);
            // 
            // updateEmployeesToolStripMenuItem
            // 
            this.updateEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.updateEmployeesToolStripMenuItem.Name = "updateEmployeesToolStripMenuItem";
            this.updateEmployeesToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.updateEmployeesToolStripMenuItem.Text = "Update Employees ";
            this.updateEmployeesToolStripMenuItem.Click += new System.EventHandler(this.updateEmployeesToolStripMenuItem_Click);
            // 
            // cALLCENTERToolStripMenuItem
            // 
            this.cALLCENTERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nEWCALLToolStripMenuItem});
            this.cALLCENTERToolStripMenuItem.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cALLCENTERToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.cALLCENTERToolStripMenuItem.Name = "cALLCENTERToolStripMenuItem";
            this.cALLCENTERToolStripMenuItem.Size = new System.Drawing.Size(126, 20);
            this.cALLCENTERToolStripMenuItem.Text = "CALL CENTER";
            // 
            // nEWCALLToolStripMenuItem
            // 
            this.nEWCALLToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.nEWCALLToolStripMenuItem.Name = "nEWCALLToolStripMenuItem";
            this.nEWCALLToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.nEWCALLToolStripMenuItem.Text = "NEW CALL";
            this.nEWCALLToolStripMenuItem.Click += new System.EventHandler(this.nEWCALLToolStripMenuItem_Click);
            // 
            // dgvTechnicalSupport
            // 
            this.dgvTechnicalSupport.BackgroundColor = System.Drawing.Color.MistyRose;
            this.dgvTechnicalSupport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTechnicalSupport.Location = new System.Drawing.Point(27, 88);
            this.dgvTechnicalSupport.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvTechnicalSupport.Name = "dgvTechnicalSupport";
            this.dgvTechnicalSupport.Size = new System.Drawing.Size(726, 162);
            this.dgvTechnicalSupport.TabIndex = 19;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.RosyBrown;
            this.btnExit.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Location = new System.Drawing.Point(643, 345);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(77, 25);
            this.btnExit.TabIndex = 25;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.RosyBrown;
            this.btnBack.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(117, 345);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(93, 25);
            this.btnBack.TabIndex = 24;
            this.btnBack.Text = "Back ";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // PreviousOperation
            // 
            this.PreviousOperation.BackColor = System.Drawing.Color.RosyBrown;
            this.PreviousOperation.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PreviousOperation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PreviousOperation.Location = new System.Drawing.Point(210, 274);
            this.PreviousOperation.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PreviousOperation.Name = "PreviousOperation";
            this.PreviousOperation.Size = new System.Drawing.Size(133, 25);
            this.PreviousOperation.TabIndex = 23;
            this.PreviousOperation.Text = "<<";
            this.PreviousOperation.UseVisualStyleBackColor = false;
            this.PreviousOperation.Click += new System.EventHandler(this.PreviousOperation_Click);
            // 
            // NextOperation
            // 
            this.NextOperation.BackColor = System.Drawing.Color.RosyBrown;
            this.NextOperation.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NextOperation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NextOperation.Location = new System.Drawing.Point(417, 274);
            this.NextOperation.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.NextOperation.Name = "NextOperation";
            this.NextOperation.Size = new System.Drawing.Size(140, 25);
            this.NextOperation.TabIndex = 22;
            this.NextOperation.Text = ">>";
            this.NextOperation.UseVisualStyleBackColor = false;
            this.NextOperation.Click += new System.EventHandler(this.NextOperation_Click);
            // 
            // LastOperation
            // 
            this.LastOperation.BackColor = System.Drawing.Color.RosyBrown;
            this.LastOperation.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastOperation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LastOperation.Location = new System.Drawing.Point(625, 274);
            this.LastOperation.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.LastOperation.Name = "LastOperation";
            this.LastOperation.Size = new System.Drawing.Size(128, 25);
            this.LastOperation.TabIndex = 21;
            this.LastOperation.Text = ">|";
            this.LastOperation.UseVisualStyleBackColor = false;
            this.LastOperation.Click += new System.EventHandler(this.LastOperation_Click);
            // 
            // FirstOperation
            // 
            this.FirstOperation.BackColor = System.Drawing.Color.RosyBrown;
            this.FirstOperation.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstOperation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FirstOperation.Location = new System.Drawing.Point(27, 274);
            this.FirstOperation.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.FirstOperation.Name = "FirstOperation";
            this.FirstOperation.Size = new System.Drawing.Size(129, 25);
            this.FirstOperation.TabIndex = 20;
            this.FirstOperation.Text = "|<";
            this.FirstOperation.UseVisualStyleBackColor = false;
            this.FirstOperation.Click += new System.EventHandler(this.FirstOperation_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(277, 51);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 16);
            this.label1.TabIndex = 26;
            this.label1.Text = "Technical Support Department";
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.RosyBrown;
            this.btnMainMenu.Font = new System.Drawing.Font("Algerian", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.Location = new System.Drawing.Point(725, 0);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(75, 38);
            this.btnMainMenu.TabIndex = 27;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // TechnicalOperationsupportDepartment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(800, 394);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.PreviousOperation);
            this.Controls.Add(this.NextOperation);
            this.Controls.Add(this.LastOperation);
            this.Controls.Add(this.FirstOperation);
            this.Controls.Add(this.dgvTechnicalSupport);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Algerian", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "TechnicalOperationsupportDepartment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TechnicalOperationsupportDepartment";
            this.Load += new System.EventHandler(this.TechnicalOperationsupportDepartment_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTechnicalSupport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem manipulateClientsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addClientsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateClientsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteClientsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manipulateEmployeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEmployeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteEmployeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateEmployeesToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgvTechnicalSupport;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button PreviousOperation;
        private System.Windows.Forms.Button NextOperation;
        private System.Windows.Forms.Button LastOperation;
        private System.Windows.Forms.Button FirstOperation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem cALLCENTERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nEWCALLToolStripMenuItem;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.ToolStripMenuItem viewEmployeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem assignOperationsToolStripMenuItem;
    }
}