﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace PresentationLayer
{
    
    public partial class ProductManagementDepartment : Form
    {
        public static DataTable newset = new DataTable();
        static Product products = new Product();
        BindingSource bind = new BindingSource();
        List<Product> ProductList = products.ReadingProducts();
        public ProductManagementDepartment()
        {
            InitializeComponent();
        }

        private void ProductManagementDepartment_Load(object sender, EventArgs e)
        {
            newset.Clear();
            newset = products.GetProducts();
            dgvProductManagement.DataSource = null;
            dgvProductManagement.DataSource = newset;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnManipulator_Click(object sender, EventArgs e)
        {
            AddProduct AP = new AddProduct();
            AP.Show();
            this.Hide();
        }

        private void FirstProduct_Click(object sender, EventArgs e)
        {

            bind.DataSource = null;
           dgvProductManagement.DataSource = null;
            bind.DataSource = ProductList;
            dgvProductManagement.DataSource = bind;
            bind.MoveFirst();
        }

        private void PreviousProduct_Click(object sender, EventArgs e)
        {

            bind.DataSource = null;
            dgvProductManagement.DataSource = null;
            bind.DataSource = ProductList;
            dgvProductManagement.DataSource = bind;
            bind.MovePrevious();
        }

        private void NextProduct_Click(object sender, EventArgs e)
        {

            bind.DataSource = null;
            dgvProductManagement.DataSource = null;
            bind.DataSource = ProductList;
            dgvProductManagement.DataSource = bind;
            bind.MoveNext();
        }

        private void LastProduct_Click(object sender, EventArgs e)
        {

            bind.DataSource = null;
            dgvProductManagement.DataSource = null;
            bind.DataSource = ProductList;
            dgvProductManagement.DataSource = bind;
            bind.MoveLast();
        }

        private void addProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddProduct ap = new AddProduct();
            this.Hide();
            ap.Show();
        
        }

        private void updateProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductManipulation mp = new ProductManipulation();
            this.Hide();
            mp.Show();
        }

        private void deleteProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteProduct dp = new DeleteProduct();
            this.Hide();
            dp.Show();

        }

        private void addEMployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddEmployee ae = new AddEmployee();
            ae.Show();
        }

        private void deleteEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteEmployee de = new DeleteEmployee();
            de.Show();
        }

        private void updateEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateEmployee ue = new UpdateEmployee();
            ue.Show();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            Main_Menu mm = new Main_Menu();
            this.Hide();
            mm.Show();
        }

        private void lblProductManagement_Click(object sender, EventArgs e)
        {

        }

        private void addOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddOrder order = new AddOrder();
            this.Hide();
            order.Show();
        }

        private void dLETEORUPDATEORDERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Orders orders = new Orders();
            this.Hide();
            orders.Show();
        }

        private void viewEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employees employees = new Employees();
            employees.Show();
        }
    }
}
