﻿namespace PresentationLayer
{


    partial class Dataset
    {
        partial class DataTable1DataTable
        {
        }
    }
}
