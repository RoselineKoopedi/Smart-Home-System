﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace PresentationLayer
{
    public partial class Tasks : Form
    {
        static Operation operations = new Operation();
        static Installation installations = new Installation();
        static Correction corrections = new Correction();
        static Residence residences = new Residence();
        static Employee employees = new Employee();
        List<Employee> employeeList = employees.ReadEmployees();
        List<Operation> operationList = operations.ReadOperations();
        List<Installation> installionList = installations.ReadInstallations();
        List<Correction> correctionList = corrections.ReadCorrections();
        List<Residence> residenceList = residences.ReadResidence();
        DataTable operation = new DataTable();
        DataTable Employee = new DataTable();
        DataTable EmployeeData = new DataTable();

        public Tasks()
        {
            InitializeComponent();
        }
        DataTable dt = new DataTable();

        private void Tasks_Load(object sender, EventArgs e)
        {
            dt = employees.GetAssignedEmployees();
            TreeViewAssign.Visible = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            TreeViewAssign.Visible = false;
            treeViewTasks.Nodes.Clear();
            operation = operations.GetOperation();
            dt = employees.GetAssignedEmployees();

            DataRowCollection rows = dt.Rows;
            DataColumnCollection column = operation.Columns;
            DataRowCollection items = operation.Rows;
            foreach (DataRow item in rows)
            {
                TreeNode node = new TreeNode(item["EmployeeName"].ToString());
                treeViewTasks.Nodes.Add(node);
                node.Nodes.Add(item[8].ToString());
                node.Nodes.Add(item[12].ToString());
            }
        }
        private void treeViewTasks_AfterSelect(object sender, TreeViewEventArgs e)
        {
            txtOperationID.Text = treeViewTasks.SelectedNode.Text;
        }

        private void btnUnassigned_Click(object sender, EventArgs e)
        {
            //Treeview for the tasks
            TreeViewAssign.Visible = true;
            treeViewTasks.Nodes.Clear();
            operation = operations.GetOperation();
            dt = employees.GetEmployyes();

            DataRowCollection rows = operation.Rows;
            DataColumnCollection column = operation.Columns;
            DataRowCollection items = dt.Rows;
            foreach (DataRow item in rows)
            {
                TreeNode node = new TreeNode(item["OperationID"].ToString());
                treeViewTasks.Nodes.Add(node);
                node.Nodes.Add(item[2].ToString());
                foreach (DataRow employees in items)
                {
                    node.Nodes[0].Nodes.Add(employees[0].ToString()   + "     "+ employees[2].ToString()+"            "+employees[3].ToString());
                }
            }

            //Treeview for emplyoyees
            Employee = employees.GetEmployyes();
            EmployeeData = employees.GetEmployyes();

            DataRowCollection row = Employee.Rows;
            DataColumnCollection columns = Employee.Columns;
            DataRowCollection itemss = EmployeeData.Rows;
            //TreeViewAssign.Nodes.Clear();
            foreach (DataRow item in row)
            {
                TreeNode node = new TreeNode(item["EmployeeID"].ToString());
                TreeViewAssign.Nodes.Add(node);
                node.Nodes.Add(item[2].ToString()  +  "      " + (item[3].ToString()));
            }
        }

        private void btnAssignOperation_Click(object sender, EventArgs e)
        {
            try
            {
                int operationID = int.Parse(txtOperationID.Text);
                int employeeID = int.Parse(txtEmployeeID.Text);
                operations.UpdateEmployeeOperation(operationID, employeeID);
                MessageBox.Show("Employee has been assigned a task to do");
                treeViewTasks.SelectedNode.Remove();
                TreeViewAssign.SelectedNode.Remove();
                txtEmployeeID.Clear();
                txtOperationID.Clear();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void TreeViewAssign_AfterSelect(object sender, TreeViewEventArgs e)
        {
            txtEmployeeID.Text = TreeViewAssign.SelectedNode.Text;
        }
    }
}
