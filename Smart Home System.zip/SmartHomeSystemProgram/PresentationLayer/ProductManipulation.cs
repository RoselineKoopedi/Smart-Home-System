﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace PresentationLayer
{
    public partial class ProductManipulation : Form
    {
        
        static Product products = new Product();
        DataTable ProductTable = new DataTable();
       
        public ProductManipulation()
        {
            InitializeComponent();
        }

        private void ProductManipulation_Load(object sender, EventArgs e)
        {
            
            ProductTable = products.GetProducts();
            cmbPID.DataSource = ProductTable;
            cmbPID.DisplayMember = "ProductID";
            cmbCategory.DataSource = ProductTable;
            cmbCategory.DisplayMember = "ProductCategory";
            cmbPID.DropDownStyle = ComboBoxStyle.DropDownList;
            txtPrice.DataBindings.Add(new Binding("Text", ProductTable, "Price"));
            txtProductName.DataBindings.Add(new Binding("Text", ProductTable, "ProductName"));
            txtQuantity.DataBindings.Add(new Binding("Text", ProductTable, "AvailableQuantity"));
           

        }

        private void cmbPID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
           string ProductID = cmbPID.Text;
            string prodName = txtProductName.Text;
            string category = cmbCategory.Text;
            int quantity = int.Parse(txtQuantity.Text);
            double price = Double.Parse(txtPrice.Text);
            string description = txtDescription.Text;
            string manufacture = txtManufacturer.Text;
            string model = txtModel.Text;
            string serialNumber = txtSerialNumber.Text;
            if (prodName != "" && ProductID.ToString() != "" && category.ToString() != "" && description.ToString() != "" && manufacture.ToString() != "" && model.ToString() != "" && serialNumber.ToString() != "")
            {
                products.UpdateProducts(ProductID, category, prodName, quantity, price, description, manufacture, model, serialNumber);
                MessageBox.Show("Product has been Updated", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("All the information is required", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ProductManagementDepartment pmd = new ProductManagementDepartment();
            this.Hide();
            pmd.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
