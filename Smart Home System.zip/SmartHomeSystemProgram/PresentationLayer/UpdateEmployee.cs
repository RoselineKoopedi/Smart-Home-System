﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace PresentationLayer
{
    public partial class UpdateEmployee : Form
    {
        static Employee employees = new Employee();
        List<Employee> employeeList = employees.ReadEmployees();
        static Department departments = new Department();
        List<Department> departmentList = departments.ReadingDepartment();
        DataTable employeeTable = new DataTable();
        public UpdateEmployee()
        {
            InitializeComponent();
        }

        private void btnManipulator_Click(object sender, EventArgs e)
        {
            int employeeID = int.Parse(cmbEmployeeID.Text);
            int departmentID = int.Parse(cmbDepartmentID.Text);
            string address = txtEmployeeAddress.Text;
            string name = txtEmployeeName.Text;
            string surname = txtEmployeeSurname.Text;
            string employeeType = txtEmployeeType.Text;
            string employeePNumber = txtEmployeePN.Text;
            employees.UpdateEmployee(employeeID, departmentID, name, surname, employeePNumber, employeeType, address);
            MessageBox.Show("Employee Updated", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void UpdateEmployee_Load(object sender, EventArgs e)
        {
            employeeTable = employees.GetEmployyes();
            cmbEmployeeID.DataSource = employeeTable;
            cmbEmployeeID.DisplayMember = "EmployeeID";
            cmbDepartmentID.DataSource = employeeTable;
            cmbDepartmentID.DisplayMember = "DepartmentID";
            cmbEmployeeID.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDepartmentID.DropDownStyle = ComboBoxStyle.DropDownList;
            txtDepartmentName.DataBindings.Add(new Binding("Text", employeeTable, "DepartmentName"));
            txtEmployeeAddress.DataBindings.Add(new Binding("Text", employeeTable, "Address"));
            txtEmployeeName.DataBindings.Add(new Binding("Text", employeeTable, "EmployeeName"));
            txtEmployeePN.DataBindings.Add(new Binding("Text", employeeTable, "EmployeePNumber"));
            txtEmployeeSurname.DataBindings.Add(new Binding("Text", employeeTable, "EmployeeSurname"));
            txtEmployeeType.DataBindings.Add(new Binding("Text", employeeTable, "EmployeeType"));
        }

        private void cmbEmployeeID_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void cmbDepartmentID_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void cmbDepartmentIID_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
