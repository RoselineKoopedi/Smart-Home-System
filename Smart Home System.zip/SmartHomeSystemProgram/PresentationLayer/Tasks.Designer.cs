﻿namespace PresentationLayer
{
    partial class Tasks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.treeViewTasks = new System.Windows.Forms.TreeView();
            this.btnAssigned = new System.Windows.Forms.Button();
            this.btnUnassigned = new System.Windows.Forms.Button();
            this.btnAssignOperation = new System.Windows.Forms.Button();
            this.checks = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TreeViewAssign = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOperationID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeViewTasks
            // 
            this.treeViewTasks.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.treeViewTasks.Location = new System.Drawing.Point(29, 78);
            this.treeViewTasks.Margin = new System.Windows.Forms.Padding(7, 4, 7, 4);
            this.treeViewTasks.Name = "treeViewTasks";
            this.treeViewTasks.Size = new System.Drawing.Size(583, 355);
            this.treeViewTasks.TabIndex = 0;
            this.treeViewTasks.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewTasks_AfterSelect);
            // 
            // btnAssigned
            // 
            this.btnAssigned.BackColor = System.Drawing.Color.RosyBrown;
            this.btnAssigned.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssigned.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAssigned.Location = new System.Drawing.Point(662, 148);
            this.btnAssigned.Margin = new System.Windows.Forms.Padding(7, 4, 7, 4);
            this.btnAssigned.Name = "btnAssigned";
            this.btnAssigned.Size = new System.Drawing.Size(192, 44);
            this.btnAssigned.TabIndex = 1;
            this.btnAssigned.Text = "View Assigned Operations";
            this.btnAssigned.UseVisualStyleBackColor = false;
            this.btnAssigned.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnUnassigned
            // 
            this.btnUnassigned.BackColor = System.Drawing.Color.RosyBrown;
            this.btnUnassigned.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUnassigned.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUnassigned.Location = new System.Drawing.Point(662, 220);
            this.btnUnassigned.Margin = new System.Windows.Forms.Padding(7, 4, 7, 4);
            this.btnUnassigned.Name = "btnUnassigned";
            this.btnUnassigned.Size = new System.Drawing.Size(192, 44);
            this.btnUnassigned.TabIndex = 2;
            this.btnUnassigned.Text = "View Unassigned Operations";
            this.btnUnassigned.UseVisualStyleBackColor = false;
            this.btnUnassigned.Click += new System.EventHandler(this.btnUnassigned_Click);
            // 
            // btnAssignOperation
            // 
            this.btnAssignOperation.BackColor = System.Drawing.Color.RosyBrown;
            this.btnAssignOperation.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignOperation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAssignOperation.Location = new System.Drawing.Point(662, 294);
            this.btnAssignOperation.Margin = new System.Windows.Forms.Padding(7, 4, 7, 4);
            this.btnAssignOperation.Name = "btnAssignOperation";
            this.btnAssignOperation.Size = new System.Drawing.Size(192, 44);
            this.btnAssignOperation.TabIndex = 3;
            this.btnAssignOperation.Text = "Assign Operation";
            this.btnAssignOperation.UseVisualStyleBackColor = false;
            this.btnAssignOperation.Click += new System.EventHandler(this.btnAssignOperation_Click);
            // 
            // checks
            // 
            this.checks.AutoSize = true;
            this.checks.Location = new System.Drawing.Point(1366, 370);
            this.checks.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.checks.Name = "checks";
            this.checks.Size = new System.Drawing.Size(0, 24);
            this.checks.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(243, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "Smart Home System Jobs";
            // 
            // TreeViewAssign
            // 
            this.TreeViewAssign.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.TreeViewAssign.Location = new System.Drawing.Point(293, 78);
            this.TreeViewAssign.Name = "TreeViewAssign";
            this.TreeViewAssign.Size = new System.Drawing.Size(319, 355);
            this.TreeViewAssign.TabIndex = 6;
            this.TreeViewAssign.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TreeViewAssign_AfterSelect);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtEmployeeID);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtOperationID);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(654, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(242, 100);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Assign Tasks";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Operation ID";
            // 
            // txtOperationID
            // 
            this.txtOperationID.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOperationID.Location = new System.Drawing.Point(133, 26);
            this.txtOperationID.Name = "txtOperationID";
            this.txtOperationID.Size = new System.Drawing.Size(100, 25);
            this.txtOperationID.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "EmployeeID";
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmployeeID.Location = new System.Drawing.Point(133, 65);
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.Size = new System.Drawing.Size(100, 25);
            this.txtEmployeeID.TabIndex = 1;
            // 
            // Tasks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(908, 446);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TreeViewAssign);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checks);
            this.Controls.Add(this.btnAssignOperation);
            this.Controls.Add(this.btnUnassigned);
            this.Controls.Add(this.btnAssigned);
            this.Controls.Add(this.treeViewTasks);
            this.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(7, 4, 7, 4);
            this.Name = "Tasks";
            this.Text = "Smart Home System Jobs";
            this.Load += new System.EventHandler(this.Tasks_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView treeViewTasks;
        private System.Windows.Forms.Button btnAssigned;
        private System.Windows.Forms.Button btnUnassigned;
        private System.Windows.Forms.Button btnAssignOperation;
        private System.Windows.Forms.Label checks;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView TreeViewAssign;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtOperationID;
        private System.Windows.Forms.Label label2;
    }
}