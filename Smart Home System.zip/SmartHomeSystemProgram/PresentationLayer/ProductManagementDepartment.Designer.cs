﻿namespace PresentationLayer
{
    partial class ProductManagementDepartment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.PreviousProduct = new System.Windows.Forms.Button();
            this.NextProduct = new System.Windows.Forms.Button();
            this.LastProduct = new System.Windows.Forms.Button();
            this.FirstProduct = new System.Windows.Forms.Button();
            this.lblProductManagement = new System.Windows.Forms.Label();
            this.dgvProductManagement = new System.Windows.Forms.DataGridView();
            this.dataTable1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetProductxsdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetProductxsd = new PresentationLayer.DataSetProductxsd();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.manipulateProductsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addProductsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateProductsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteProductsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manipulateEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEMployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manipulateOrdersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dLETEORUPDATEORDERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataset = new PresentationLayer.Dataset();
            this.residencesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.residencesTableAdapter = new PresentationLayer.DatasetTableAdapters.ResidencesTableAdapter();
            this.newDataSet = new PresentationLayer.NewDataSet();
            this.newDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataTable1TableAdapter = new PresentationLayer.NewDataSetTableAdapters.DataTable1TableAdapter();
            this.dataTable1TableAdapter1 = new PresentationLayer.DataSetProductxsdTableAdapters.DataTable1TableAdapter();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.viewEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductManagement)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetProductxsdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetProductxsd)).BeginInit();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.residencesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.newDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.newDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.RosyBrown;
            this.btnExit.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Location = new System.Drawing.Point(566, 400);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 36);
            this.btnExit.TabIndex = 34;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.RosyBrown;
            this.btnBack.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(12, 400);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 36);
            this.btnBack.TabIndex = 32;
            this.btnBack.Text = "Back ";
            this.btnBack.UseVisualStyleBackColor = false;
            // 
            // PreviousProduct
            // 
            this.PreviousProduct.BackColor = System.Drawing.Color.RosyBrown;
            this.PreviousProduct.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PreviousProduct.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PreviousProduct.Location = new System.Drawing.Point(166, 325);
            this.PreviousProduct.Name = "PreviousProduct";
            this.PreviousProduct.Size = new System.Drawing.Size(75, 33);
            this.PreviousProduct.TabIndex = 31;
            this.PreviousProduct.Text = "<<";
            this.PreviousProduct.UseVisualStyleBackColor = false;
            this.PreviousProduct.Click += new System.EventHandler(this.PreviousProduct_Click);
            // 
            // NextProduct
            // 
            this.NextProduct.BackColor = System.Drawing.Color.RosyBrown;
            this.NextProduct.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NextProduct.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NextProduct.Location = new System.Drawing.Point(371, 325);
            this.NextProduct.Name = "NextProduct";
            this.NextProduct.Size = new System.Drawing.Size(75, 33);
            this.NextProduct.TabIndex = 30;
            this.NextProduct.Text = ">>";
            this.NextProduct.UseVisualStyleBackColor = false;
            this.NextProduct.Click += new System.EventHandler(this.NextProduct_Click);
            // 
            // LastProduct
            // 
            this.LastProduct.BackColor = System.Drawing.Color.RosyBrown;
            this.LastProduct.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastProduct.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LastProduct.Location = new System.Drawing.Point(520, 325);
            this.LastProduct.Name = "LastProduct";
            this.LastProduct.Size = new System.Drawing.Size(75, 33);
            this.LastProduct.TabIndex = 29;
            this.LastProduct.Text = ">|";
            this.LastProduct.UseVisualStyleBackColor = false;
            this.LastProduct.Click += new System.EventHandler(this.LastProduct_Click);
            // 
            // FirstProduct
            // 
            this.FirstProduct.BackColor = System.Drawing.Color.RosyBrown;
            this.FirstProduct.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstProduct.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FirstProduct.Location = new System.Drawing.Point(58, 325);
            this.FirstProduct.Name = "FirstProduct";
            this.FirstProduct.Size = new System.Drawing.Size(75, 33);
            this.FirstProduct.TabIndex = 28;
            this.FirstProduct.Text = "|<";
            this.FirstProduct.UseVisualStyleBackColor = false;
            this.FirstProduct.Click += new System.EventHandler(this.FirstProduct_Click);
            // 
            // lblProductManagement
            // 
            this.lblProductManagement.AutoSize = true;
            this.lblProductManagement.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductManagement.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblProductManagement.Location = new System.Drawing.Point(228, 66);
            this.lblProductManagement.Name = "lblProductManagement";
            this.lblProductManagement.Size = new System.Drawing.Size(303, 16);
            this.lblProductManagement.TabIndex = 27;
            this.lblProductManagement.Text = "Product Management Department";
            this.lblProductManagement.Click += new System.EventHandler(this.lblProductManagement_Click);
            // 
            // dgvProductManagement
            // 
            this.dgvProductManagement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductManagement.Location = new System.Drawing.Point(58, 102);
            this.dgvProductManagement.Name = "dgvProductManagement";
            this.dgvProductManagement.Size = new System.Drawing.Size(537, 199);
            this.dgvProductManagement.TabIndex = 16;
            // 
            // dataTable1BindingSource1
            // 
            this.dataTable1BindingSource1.DataMember = "DataTable1";
            this.dataTable1BindingSource1.DataSource = this.dataSetProductxsdBindingSource;
            // 
            // dataSetProductxsdBindingSource
            // 
            this.dataSetProductxsdBindingSource.DataSource = this.dataSetProductxsd;
            this.dataSetProductxsdBindingSource.Position = 0;
            // 
            // dataSetProductxsd
            // 
            this.dataSetProductxsd.DataSetName = "DataSetProductxsd";
            this.dataSetProductxsd.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 24);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(664, 24);
            this.menuStrip1.TabIndex = 37;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manipulateProductsToolStripMenuItem,
            this.manipulateEmployeesToolStripMenuItem,
            this.manipulateOrdersToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(664, 24);
            this.menuStrip2.TabIndex = 38;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // manipulateProductsToolStripMenuItem
            // 
            this.manipulateProductsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addProductsToolStripMenuItem,
            this.updateProductsToolStripMenuItem,
            this.deleteProductsToolStripMenuItem});
            this.manipulateProductsToolStripMenuItem.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manipulateProductsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.manipulateProductsToolStripMenuItem.Name = "manipulateProductsToolStripMenuItem";
            this.manipulateProductsToolStripMenuItem.Size = new System.Drawing.Size(206, 20);
            this.manipulateProductsToolStripMenuItem.Text = "Manipulate Products";
            // 
            // addProductsToolStripMenuItem
            // 
            this.addProductsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.addProductsToolStripMenuItem.Name = "addProductsToolStripMenuItem";
            this.addProductsToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.addProductsToolStripMenuItem.Text = "Add Products";
            this.addProductsToolStripMenuItem.Click += new System.EventHandler(this.addProductsToolStripMenuItem_Click);
            // 
            // updateProductsToolStripMenuItem
            // 
            this.updateProductsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.updateProductsToolStripMenuItem.Name = "updateProductsToolStripMenuItem";
            this.updateProductsToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.updateProductsToolStripMenuItem.Text = "Update Products";
            this.updateProductsToolStripMenuItem.Click += new System.EventHandler(this.updateProductsToolStripMenuItem_Click);
            // 
            // deleteProductsToolStripMenuItem
            // 
            this.deleteProductsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.deleteProductsToolStripMenuItem.Name = "deleteProductsToolStripMenuItem";
            this.deleteProductsToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.deleteProductsToolStripMenuItem.Text = "Delete Products";
            this.deleteProductsToolStripMenuItem.Click += new System.EventHandler(this.deleteProductsToolStripMenuItem_Click);
            // 
            // manipulateEmployeesToolStripMenuItem
            // 
            this.manipulateEmployeesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewEmployeesToolStripMenuItem,
            this.addEMployeeToolStripMenuItem,
            this.deleteEmployeesToolStripMenuItem,
            this.updateEmployeesToolStripMenuItem});
            this.manipulateEmployeesToolStripMenuItem.Font = new System.Drawing.Font("Algerian", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manipulateEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.manipulateEmployeesToolStripMenuItem.Name = "manipulateEmployeesToolStripMenuItem";
            this.manipulateEmployeesToolStripMenuItem.Size = new System.Drawing.Size(217, 20);
            this.manipulateEmployeesToolStripMenuItem.Text = "Manipulate Employees";
            // 
            // addEMployeeToolStripMenuItem
            // 
            this.addEMployeeToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.addEMployeeToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.addEMployeeToolStripMenuItem.Name = "addEMployeeToolStripMenuItem";
            this.addEMployeeToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.addEMployeeToolStripMenuItem.Text = "Add Employees";
            this.addEMployeeToolStripMenuItem.Click += new System.EventHandler(this.addEMployeeToolStripMenuItem_Click);
            // 
            // deleteEmployeesToolStripMenuItem
            // 
            this.deleteEmployeesToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.deleteEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.deleteEmployeesToolStripMenuItem.Name = "deleteEmployeesToolStripMenuItem";
            this.deleteEmployeesToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.deleteEmployeesToolStripMenuItem.Text = "Delete Employees";
            this.deleteEmployeesToolStripMenuItem.Click += new System.EventHandler(this.deleteEmployeesToolStripMenuItem_Click);
            // 
            // updateEmployeesToolStripMenuItem
            // 
            this.updateEmployeesToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.updateEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.updateEmployeesToolStripMenuItem.Name = "updateEmployeesToolStripMenuItem";
            this.updateEmployeesToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.updateEmployeesToolStripMenuItem.Text = "Update Employees";
            this.updateEmployeesToolStripMenuItem.Click += new System.EventHandler(this.updateEmployeesToolStripMenuItem_Click);
            // 
            // manipulateOrdersToolStripMenuItem
            // 
            this.manipulateOrdersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addOrderToolStripMenuItem,
            this.dLETEORUPDATEORDERToolStripMenuItem});
            this.manipulateOrdersToolStripMenuItem.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manipulateOrdersToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.manipulateOrdersToolStripMenuItem.Name = "manipulateOrdersToolStripMenuItem";
            this.manipulateOrdersToolStripMenuItem.Size = new System.Drawing.Size(167, 20);
            this.manipulateOrdersToolStripMenuItem.Text = "Manipulate Orders";
            // 
            // addOrderToolStripMenuItem
            // 
            this.addOrderToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.addOrderToolStripMenuItem.Name = "addOrderToolStripMenuItem";
            this.addOrderToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.addOrderToolStripMenuItem.Text = "Add Order";
            this.addOrderToolStripMenuItem.Click += new System.EventHandler(this.addOrderToolStripMenuItem_Click);
            // 
            // dLETEORUPDATEORDERToolStripMenuItem
            // 
            this.dLETEORUPDATEORDERToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.dLETEORUPDATEORDERToolStripMenuItem.Name = "dLETEORUPDATEORDERToolStripMenuItem";
            this.dLETEORUPDATEORDERToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.dLETEORUPDATEORDERToolStripMenuItem.Text = "VIEW ORDERS";
            this.dLETEORUPDATEORDERToolStripMenuItem.Click += new System.EventHandler(this.dLETEORUPDATEORDERToolStripMenuItem_Click);
            // 
            // dataset
            // 
            this.dataset.DataSetName = "Dataset";
            this.dataset.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // residencesBindingSource
            // 
            this.residencesBindingSource.DataMember = "Residences";
            this.residencesBindingSource.DataSource = this.dataset;
            // 
            // residencesTableAdapter
            // 
            this.residencesTableAdapter.ClearBeforeFill = true;
            // 
            // newDataSet
            // 
            this.newDataSet.DataSetName = "NewDataSet";
            this.newDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // newDataSetBindingSource
            // 
            this.newDataSetBindingSource.DataSource = this.newDataSet;
            this.newDataSetBindingSource.Position = 0;
            // 
            // dataTable1BindingSource
            // 
            this.dataTable1BindingSource.DataMember = "DataTable1";
            this.dataTable1BindingSource.DataSource = this.newDataSetBindingSource;
            // 
            // dataTable1TableAdapter
            // 
            this.dataTable1TableAdapter.ClearBeforeFill = true;
            // 
            // dataTable1TableAdapter1
            // 
            this.dataTable1TableAdapter1.ClearBeforeFill = true;
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Font = new System.Drawing.Font("Algerian", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.Location = new System.Drawing.Point(589, 0);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(75, 38);
            this.btnMainMenu.TabIndex = 39;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // viewEmployeesToolStripMenuItem
            // 
            this.viewEmployeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.viewEmployeesToolStripMenuItem.Name = "viewEmployeesToolStripMenuItem";
            this.viewEmployeesToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.viewEmployeesToolStripMenuItem.Text = "View Employees";
            this.viewEmployeesToolStripMenuItem.Click += new System.EventHandler(this.viewEmployeesToolStripMenuItem_Click);
            // 
            // ProductManagementDepartment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(664, 448);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.PreviousProduct);
            this.Controls.Add(this.NextProduct);
            this.Controls.Add(this.LastProduct);
            this.Controls.Add(this.FirstProduct);
            this.Controls.Add(this.lblProductManagement);
            this.Controls.Add(this.dgvProductManagement);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ProductManagementDepartment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Management Department";
            this.Load += new System.EventHandler(this.ProductManagementDepartment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductManagement)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetProductxsdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetProductxsd)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.residencesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.newDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.newDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button PreviousProduct;
        private System.Windows.Forms.Button NextProduct;
        private System.Windows.Forms.Button LastProduct;
        private System.Windows.Forms.Button FirstProduct;
        private System.Windows.Forms.Label lblProductManagement;
        private System.Windows.Forms.DataGridView dgvProductManagement;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem manipulateProductsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addProductsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateProductsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteProductsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manipulateEmployeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEMployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteEmployeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateEmployeesToolStripMenuItem;
        private Dataset dataset;
        private System.Windows.Forms.BindingSource residencesBindingSource;
        private DatasetTableAdapters.ResidencesTableAdapter residencesTableAdapter;
        private System.Windows.Forms.BindingSource newDataSetBindingSource;
        private NewDataSet newDataSet;
        private System.Windows.Forms.BindingSource dataTable1BindingSource;
        private NewDataSetTableAdapters.DataTable1TableAdapter dataTable1TableAdapter;
        private System.Windows.Forms.BindingSource dataSetProductxsdBindingSource;
        private DataSetProductxsd dataSetProductxsd;
        private System.Windows.Forms.BindingSource dataTable1BindingSource1;
        private DataSetProductxsdTableAdapters.DataTable1TableAdapter dataTable1TableAdapter1;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.ToolStripMenuItem manipulateOrdersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dLETEORUPDATEORDERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewEmployeesToolStripMenuItem;
    }
}