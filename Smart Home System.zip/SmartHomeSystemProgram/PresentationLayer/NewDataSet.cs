﻿namespace PresentationLayer
{


    partial class NewDataSet
    {
        partial class DataTable1DataTable
        {
        }
    }
}
