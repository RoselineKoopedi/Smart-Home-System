﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace PresentationLayer
{
    public partial class TechnicalOperationsupportDepartment : Form
    {
        static Operation operations = new Operation();
        //  List<Operation> OperationList = operations.ReadOperations();
        Employee emps = new Employee();
        static DataTable OperationTable = new DataTable();
        BindingSource bs = new BindingSource();
        public TechnicalOperationsupportDepartment()
        {
            InitializeComponent();
        }

        private void addEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddEmployee ae = new AddEmployee();
            ae.Show();
        }

        private void deleteEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteEmployee de = new DeleteEmployee();
            de.Show();
        }

        private void updateEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateEmployee ue = new UpdateEmployee();
            ue.Show();
        }

        private void addClientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddOperation ao = new AddOperation();
            ao.Show();
        }

        private void updateClientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OperationManipulation om = new OperationManipulation();
            om.Show();
        }

        private void deleteClientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteOperation dop = new DeleteOperation();
            dop.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            TechnicalSupportLogin tsl = new TechnicalSupportLogin();
            this.Close();
            tsl.Show();
        }

        private void TechnicalOperationsupportDepartment_Load(object sender, EventArgs e)
        {
             OperationTable = operations.GetOperation();
             bs.DataSource = OperationTable;
             dgvTechnicalSupport.DataSource = bs;
             dgvTechnicalSupport.DataSource = OperationTable;

        }

        private void FirstOperation_Click(object sender, EventArgs e)
        {
            bs.DataSource = null;
            dgvTechnicalSupport.DataSource = null;
            OperationTable = operations.GetOperation();
            bs.DataSource = OperationTable;
            dgvTechnicalSupport.DataSource = bs;
            bs.MoveFirst();
        }

        private void PreviousOperation_Click(object sender, EventArgs e)
        {
            bs.DataSource = null;
            dgvTechnicalSupport.DataSource = null;
            OperationTable = operations.GetOperation();
            bs.DataSource = OperationTable;
            dgvTechnicalSupport.DataSource = bs;
            bs.MovePrevious();
        }

        private void NextOperation_Click(object sender, EventArgs e)
        {
            bs.DataSource = null;
            dgvTechnicalSupport.DataSource = null;
            OperationTable = operations.GetOperation();
            bs.DataSource = OperationTable;
            dgvTechnicalSupport.DataSource = bs;
            bs.MoveNext();
        }

        private void LastOperation_Click(object sender, EventArgs e)
        {
            bs.DataSource = null;
            dgvTechnicalSupport.DataSource = null;
            OperationTable = operations.GetOperation();
            bs.DataSource = OperationTable;
            dgvTechnicalSupport.DataSource = bs;
            bs.MoveLast();
        }

        private void nEWCALLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CallCenter cc = new CallCenter();
            cc.Show();
        }

        private void viewAllCallRecordsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            Main_Menu mm = new Main_Menu();
            this.Hide();
            mm.Show();
        }

        private void viewEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employees employees = new Employees();
            employees.Show();
        }

        private void assignOperationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tasks tasks = new Tasks();
            tasks.Show();

        }
    }
}
