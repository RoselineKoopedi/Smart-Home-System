﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class Product : Residence
    {

        private string productID;
        private string category;
        private string productName;
        private int availableQuantity;
        private double price;
        private string description;
        private string manufacturer;
        private string model;
        private string serialNumber;

        public string ProductID
        {
            get
            {
                return productID;
            }

            set
            {
                productID = value;
            }
        }

        public string ProductName
        {
            get
            {
                return productName;
            }

            set
            {
                productName = value;
            }
        }

        public string Category
        {
            get
            {
                return category;
            }

            set
            {
                category = value;
            }
        }

        public int AvailableQuantity
        {
            get
            {
                return availableQuantity;
            }

            set
            {
                availableQuantity = value;
            }
        }

        public double Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }

        public string Description
        {
            get
            {
                return description;
            }

            set
            {
                description = value;
            }
        }

        public string Manufacturer
        {
            get
            {
                return manufacturer;
            }

            set
            {
                manufacturer = value;
            }
        }

        public string Model
        {
            get
            {
                return model;
            }

            set
            {
                model = value;
            }
        }

        public string SerialNumber
        {
            get
            {
                return serialNumber;
            }

            set
            {
                serialNumber = value;
            }
        }

        public Product()
        {

        }
        public Product(string productID, string category, string productName, int quantity, double Price, string description, string manufacturer, string model, string serialNumber)
        {
            this.ProductID = productID;
            this.category = category;
            this.ProductName = productName;
            this.availableQuantity = quantity;
            this.price = Price;
        }
        public Product(string productID,string clientID,string cat, string productName)
        {
            this.ProductID = productID;
            this.ClientID = clientID;
            this.category = cat;
            this.ProductName = productName;
        }
          public Product(int residenceID, string address)
              :base( residenceID,address)
          {

          }
        public static DataTable dataT = new DataTable();

         public DataTable GetProducts()
        {
            ProductDataHandler productdate = new ProductDataHandler();
            dataT = productdate.GetProducts("ProductTable");
            return dataT;
        }
       
        public static DataTable FilteredData = new DataTable();
        public DataTable FilteredOrders(string category)
        {
            ProductDataHandler productdate = new ProductDataHandler();
            FilteredData = productdate.FilterOrders("ProductTable", category);
            return FilteredData;
        }
        public List<Product> ProductsPrices()
        {
            List<Product> ReadProducts = new List<Product>();
            DataSet GetClients = new ProductDataHandler().ReadProducts("ProductTable");
            foreach (DataRow item in GetClients.Tables["ProductTable"].Rows)
            {
                ReadProducts.Add(new Product(item["ProductID"].ToString(), item["ProductCategory"].ToString(), item["ProductName"].ToString(), int.Parse(item["AvailableQuantity"].ToString()), Double.Parse(item["Price"].ToString()), item["Description"].ToString(), item["Manufacturer"].ToString(), item["Model"].ToString(), item["SerialNumber"].ToString()));
            }
            return ReadProducts;
        }
        public List<Product> ReadingProducts()
        {
            List<Product> ReadProducts = new List<Product>();
            DataSet GetClients = new ProductDataHandler().ReadProducts("ProductTable");
            foreach (DataRow item in GetClients.Tables["ProductTable"].Rows)
            {
                ReadProducts.Add(new Product(item["ProductID"].ToString(), item["ProductCategory"].ToString(), item["ProductName"].ToString(),int.Parse(item["AvailableQuantity"].ToString()), Double.Parse(item["Price"].ToString()), item["Description"].ToString(), item["Manufacturer"].ToString(), item["Model"].ToString(), item["SerialNumber"].ToString()));

            }
            return ReadProducts;
        }
      
        public void InsertProducts(string ProductID, string ProductCategory, string ProductName, int AvailableQuantity, double Price, string description, string manufacturer, string model, string serialNumber)
        {
            new ProductDataHandler().InsertProduct(ProductID, ProductCategory, ProductName, AvailableQuantity, Price, description, manufacturer, model, serialNumber);
        }
        public void UpdateProducts(string ProductID, string ProductCategory, string ProductName, int AvailableQuantity, double Price, string description, string manufacturer, string model, string serialNumber)
        {
            new ProductDataHandler().UpdateProduct(ProductID, ProductCategory, ProductName, AvailableQuantity, Price, description, manufacturer, model, serialNumber);
        }
        public void UpdateQuantity(string ProductName, int AvailableQuantity)
        {
            new ProductDataHandler().UpdateQuantity(ProductName, AvailableQuantity);
        }
        public void DeleteProduct(string productID)
        {
            new ProductDataHandler().DeleteProduct(productID);
        }


    }
}
