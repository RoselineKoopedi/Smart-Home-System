﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class Installation : Operation
    {
        private int installationID;
        private DateTime installationDate;

        public int InstallationID
        {
            get
            {
                return installationID;
            }

            set
            {
                installationID = value;
            }
        }


        public DateTime InstallationDate
        {
            get
            {
                return installationDate;
            }

            set
            {
                installationDate = value;
            }
        }
        public Installation()
        {

        }
        public Installation(int instalID, int operationID, int residenceID, DateTime InstalDate)
        {
            this.InstallationID = instalID;
            this.OperationID = operationID;
            this.ResidenceID = residenceID;
            this.InstallationDate = InstalDate;
        }
    
    public List<Installation> ReadInstallations()
        {
            List<Installation> GetInstallation = new List<Installation>();
            DataSet InstallationData = new InstallationDataHandler().ReadInstallation("Installation");

            foreach (DataRow item in InstallationData.Tables["Installation"].Rows)
            {
                GetInstallation.Add(new Installation(int.Parse(item["InstallationID"].ToString()), int.Parse(item["OperationID"].ToString()), int.Parse(item["ResidenceID"].ToString()), DateTime.Parse(item["InstallationDate"].ToString())));
            }

            return GetInstallation;
        }

        public void InsertInstallation(int InstallationID, int OperationID,int ResidenceID,DateTime InstallationDate)
        {
            new InstallationDataHandler().InsertInstallation(InstallationID, OperationID, ResidenceID, InstallationDate);
        }
        public void UpdateInstallation(int InstallationID, int OperationID, int ResidenceID, DateTime InstallationDate)
        {
            new InstallationDataHandler().UpdateInstallation(InstallationID, OperationID, ResidenceID, InstallationDate);
        }
        public void DeleteInstallation(int InstallationID)
        {
            new InstallationDataHandler().DeleteInstallation(InstallationID);

        }

    }
}
