﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PresentationLayer;

namespace SmartHomeSystemProgram
{
    public partial class SmartHome : Form
    {
        public SmartHome()
        {
            InitializeComponent();
        }

        private void SmartHome_Load(object sender, EventArgs e)
        {
           
        }

        private void btnProductManagement_Click(object sender, EventArgs e)
        {
            ProductManagerLogin PML = new ProductManagerLogin();
            PML.Show();
            this.Hide();
        }

        private void txtTester_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnClientManagement_Click(object sender, EventArgs e)
        {
            ClientManagerLogin CML = new ClientManagerLogin();
            CML.Show();
            this.Hide();
        }

        private void btnTechinalSupport_Click(object sender, EventArgs e)
        {
           TechnicalSupportLogin TSL = new TechnicalSupportLogin();
            TSL.Show();
            this.Hide();
        }

        private void btnExist_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnTemporary_Click(object sender, EventArgs e)
        {
            CallCenter cc = new CallCenter();
            cc.Show();
        }
    }
}
