﻿namespace SmartHomeSystemProgram
{
    partial class SmartHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SmartHome));
            this.btnClientManagement = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnProductManagement = new System.Windows.Forms.Button();
            this.btnTechinalSupport = new System.Windows.Forms.Button();
            this.btnExist = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnClientManagement
            // 
            this.btnClientManagement.BackColor = System.Drawing.Color.RosyBrown;
            this.btnClientManagement.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClientManagement.BackgroundImage")));
            this.btnClientManagement.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClientManagement.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClientManagement.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnClientManagement.Location = new System.Drawing.Point(38, 90);
            this.btnClientManagement.Name = "btnClientManagement";
            this.btnClientManagement.Size = new System.Drawing.Size(133, 128);
            this.btnClientManagement.TabIndex = 0;
            this.btnClientManagement.Text = "Client Management Department";
            this.btnClientManagement.UseVisualStyleBackColor = false;
            this.btnClientManagement.Click += new System.EventHandler(this.btnClientManagement_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Wide Latin", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(34, 43);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(475, 19);
            this.lblWelcome.TabIndex = 1;
            this.lblWelcome.Text = "Welcome to Smart Home System";
            // 
            // btnProductManagement
            // 
            this.btnProductManagement.BackColor = System.Drawing.Color.RosyBrown;
            this.btnProductManagement.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnProductManagement.BackgroundImage")));
            this.btnProductManagement.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProductManagement.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductManagement.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnProductManagement.Location = new System.Drawing.Point(206, 90);
            this.btnProductManagement.Name = "btnProductManagement";
            this.btnProductManagement.Size = new System.Drawing.Size(133, 128);
            this.btnProductManagement.TabIndex = 2;
            this.btnProductManagement.Text = "Product Management Department";
            this.btnProductManagement.UseVisualStyleBackColor = false;
            this.btnProductManagement.Click += new System.EventHandler(this.btnProductManagement_Click);
            // 
            // btnTechinalSupport
            // 
            this.btnTechinalSupport.BackColor = System.Drawing.Color.RosyBrown;
            this.btnTechinalSupport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTechinalSupport.BackgroundImage")));
            this.btnTechinalSupport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTechinalSupport.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTechinalSupport.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnTechinalSupport.Location = new System.Drawing.Point(376, 90);
            this.btnTechinalSupport.Name = "btnTechinalSupport";
            this.btnTechinalSupport.Size = new System.Drawing.Size(133, 128);
            this.btnTechinalSupport.TabIndex = 3;
            this.btnTechinalSupport.Text = "Technical Support Department";
            this.btnTechinalSupport.UseVisualStyleBackColor = false;
            this.btnTechinalSupport.Click += new System.EventHandler(this.btnTechinalSupport_Click);
            // 
            // btnExist
            // 
            this.btnExist.BackColor = System.Drawing.Color.RosyBrown;
            this.btnExist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExist.Location = new System.Drawing.Point(469, 0);
            this.btnExist.Name = "btnExist";
            this.btnExist.Size = new System.Drawing.Size(50, 23);
            this.btnExist.TabIndex = 4;
            this.btnExist.Text = "Exit";
            this.btnExist.UseVisualStyleBackColor = false;
            this.btnExist.Click += new System.EventHandler(this.btnExist_Click);
            // 
            // SmartHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(519, 252);
            this.Controls.Add(this.btnExist);
            this.Controls.Add(this.btnTechinalSupport);
            this.Controls.Add(this.btnProductManagement);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnClientManagement);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "SmartHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Home System";
            this.Load += new System.EventHandler(this.SmartHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClientManagement;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnProductManagement;
        private System.Windows.Forms.Button btnTechinalSupport;
        private System.Windows.Forms.Button btnExist;
    }
}

